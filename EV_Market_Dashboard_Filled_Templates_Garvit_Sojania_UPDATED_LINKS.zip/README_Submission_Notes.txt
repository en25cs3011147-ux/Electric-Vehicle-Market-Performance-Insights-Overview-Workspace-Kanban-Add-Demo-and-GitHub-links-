EV MARKET PERFORMANCE & INSIGHTS DASHBOARD — SUBMISSION NOTES
Date: 27 October 2026
Student: Garvit Sojania | Enrollment No.: EN25CS3011147
Dashboard: https://public.tableau.com/app/profile/garvit.sojania/viz/EVMarketAnalysisDashboard_17932678752010/Dashboard1?publish=yes
GitHub: https://github.com/en25cs3011147-ux/Electric-Vehicle-Market-Performance-Insights-Overview-Workspace-Kanban-Add-Demo-and-GitHub-links-

Project facts used: approx. 199,999 distinct Vehicle Id records; average battery capacity 78.24 kWh; average driving range 324.5 km; charts by manufacturer and manufacturing country.

Important accuracy notes: This is an individual Tableau project. Snowflake is not part of the implemented stack; Snowflake-specific templates are marked not applicable rather than inventing SQL or test results. Formal performance timings, null/duplicate audit outputs, user testing, and a separate Tableau Story object were not provided and are not claimed as completed. Planned sprint estimates are planning assumptions, not verified historical tracking data.

Before submission: open the dashboard and GitHub links, confirm the workbook and screenshot are present, and verify any instructor-required Team ID if one was assigned.

Student Name: Garvit Sojania
Enrollment No.: EN25CS3011147
